#!/bin/bash

echo "HID Global Biometrics Lumidigm SEngine install."

if [[ $EUID -ne "0" ]]; then
	echo
	echo "================================================================"
	echo
	echo "Error: this script must have root privilege to do its job."
	echo
	echo "Example usage: sudo $0"
	echo
	exit 1
fi

if [[ $SUDO_UID -eq 0 ]]; then
	echo
	echo "================================================================"
	echo
	echo "Warning: IDDB is being installed as root."
	echo "         This implies that SEngine shall be run as root."
	echo "         This is not recommended."
	echo
	echo "Ctrl-C to abort, Enter to continue."
	read LINE
else
	echo "Installing IDDB for user: $SUDO_USER"
fi

if [ -d /usr/local/Lumidigm ]; then
    rm -rf /usr/local/Lumidigm-save
    mv /usr/local/Lumidigm /usr/local/Lumidigm-save > /dev/null 2>&1
fi

if [ -d /usr/local/HID_Global/Lumidigm ]; then
    rm -rf /usr/local/HID_Global/Lumidigm-save
    mv /usr/local/HID_Global/Lumidigm /usr/local/HID_Global/Lumidigm-save > /dev/null 2>&1
fi

rm -f /etc/udev/rules.d/88-Lumidigm.rules.save
mv /etc/udev/rules.d/88-Lumidigm.rules /etc/udev/rules.d/88-Lumidigm.rules.save > /dev/null 2>&1

install -d --mode 755 --owner root       --group root /usr/local/HID_Global/Lumidigm
install -d --mode 755 --owner root       --group root /usr/local/HID_Global/Lumidigm/lib
install -d --mode 755 --owner root       --group root /usr/local/HID_Global/Lumidigm/bin
install -d --mode 755 --owner root       --group root /usr/local/HID_Global/Lumidigm/var
install -d --mode 755 --owner root       --group root /usr/local/HID_Global/Lumidigm/var/lib
install -d --mode 755 --owner root       --group root /usr/local/HID_Global/Lumidigm/var/lib/xml
install -d --mode 755 --owner root       --group root /usr/local/HID_Global/Lumidigm/var/lib/SPM
install -d --mode 700 --owner $SUDO_USER --group root /usr/local/HID_Global/Lumidigm/var/lib/IDDB

install    --mode 755 --owner root       --group root lib/libSEngine.so.* /usr/local/HID_Global/Lumidigm/lib
ln -s /usr/local/HID_Global/Lumidigm/lib/libSEngine.so.* /usr/local/HID_Global/Lumidigm/lib/libSEngine.so

install    --mode 755 --owner root       --group root bin/LumiDownloader /usr/local/HID_Global/Lumidigm/bin
install    --mode 755 --owner root       --group root bin/udev-pm.sh /usr/local/HID_Global/Lumidigm/bin
install    --mode 755 --owner root       --group root bin/V31X.hex /usr/local/HID_Global/Lumidigm/bin
install    --mode 755 --owner root       --group root bin/M31X.hex /usr/local/HID_Global/Lumidigm/bin

install    --mode 644 --owner root       --group root var/lib/xml/SEDevConfig.xml /usr/local/HID_Global/Lumidigm/var/lib/xml

install    --mode 644 --owner root       --group root var/lib/SPM/eSPM_1.bin /usr/local/HID_Global/Lumidigm/var/lib/SPM

install    --mode 644 --owner root       --group root driver/88-Lumidigm.rules /etc/udev/rules.d


echo "Done."
